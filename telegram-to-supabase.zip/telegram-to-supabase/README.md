# Telegram → Supabase → AI Summarizer (OpenAI/xAI) → Frontend

End-to-end pipeline:
- **Render worker** ingests Telegram messages into Supabase
- **Supabase Edge Function** summarizes + classifies sentiment + extracts token insights
- **Frontend (lovable.dev)** displays latest summary and per-token signals
- **Scheduler** (Supabase Scheduled Functions) runs summarize periodically

---

## 1) Supabase Setup

Run the SQL:
```
\i supabase/migrations.sql
```

Then deploy the Edge Function:
```
cd supabase/functions/summarize
supabase functions deploy summarize
```

Grant env vars in Supabase project (Settings → Functions → Secrets):
- `SUPABASE_URL`
- `SUPABASE_SERVICE_KEY`
- `AI_PROVIDER` = `openai` or `xai`
- `OPENAI_API_KEY` (if using OpenAI)
- `XAI_API_KEY` (if using xAI)

---

## 2) Render Worker (Telegram ingestion)

```
cd worker
npm i
```
Ensure env vars in Render:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_KEY`
- `TELEGRAM_BOT_TOKEN`
- `ALLOWED_CHAT_IDS` (optional)

Start command: `node index.js`

You can use the included `render.yaml` to create the Worker service.

---

## 3) Scheduler (Supabase Scheduled Functions)

In Supabase Dashboard → **Edge Functions → Schedules → New Schedule**:
- Function: `summarize`
- Method: `POST`
- Cron: every 10 minutes → `*/10 * * * *`
- Payload: empty

Alternatively with CLI:
```
supabase functions schedule create summarize-every-10   --function summarize   --cron "*/10 * * * *"   --request-body "{}"   --request-method POST
```

This will call the summarize function every 10 minutes to process new messages.

---

## 4) Frontend (lovable.dev)

Use the provided component:
```
frontend/components/TelegramIntelligenceCard.tsx
```
It invokes the summarize function (optional) and reads from the `v_latest_telegram_intel` view.

Set env:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

---

## 5) Notes

- If you need private channels, consider a full Telegram Client (GramJS / Telethon). The worker sample uses the Bot API.
- The Edge Function constrains token analysis with a local extractor; you can expand `COMMON` or add contract indexers.
- RLS: raw tables are service-only; aggregate intel is public (read) for easy frontend consumption.
- Switch providers by changing `AI_PROVIDER` env without code changes.
